#!/bin/bash

chmod 777 sysadmin/ip/ipp
./sysadmin/ip/ipp