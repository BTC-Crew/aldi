#!/bin/bash

read -p "INPUTKAN PORT YANG ANDA INGINKAN = " port;

echo 'Port                            '$port >> /etc/proftpd/proftpd.conf