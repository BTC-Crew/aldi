#!/bin/bash

read -p "MASUKAN NameServer Anda = " name;

echo 'ServerName                      ''"'$name'"' >> /etc/proftpd/proftpd.conf