#!/bin/bash

echo 'ServerName                      "Debian"' >> /etc/proftpd/proftpd.conf