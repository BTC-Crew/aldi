#!/bin/bash

echo 'Port                            21' >> /etc/proftpd/proftpd.conf