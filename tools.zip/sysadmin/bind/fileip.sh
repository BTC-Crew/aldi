#!/bin/bash

read -p " CREATE FILE FOR DB.127            = " nama;
read -p " MASUKAN DOMAIN YANG DI INGINKAN   = " domain;
read -p " MASUKAN IP TERAKHIR ANDA          = " ip;

echo ';' >> /etc/bind/$nama
echo '; BIND reverse data file for local loopback interface' >> /etc/bind/$nama
echo ';' >> /etc/bind/$nama
echo '$TTL    604800' >> /etc/bind/$nama
echo '@       IN      SOA     '$domain'. root.'$domain'. (' >> /etc/bind/$nama
echo '                             1         ; Serial' >> /etc/bind/$nama
echo '                        604800         ; Refresh' >> /etc/bind/$nama
echo '                         86400         ; Retry' >> /etc/bind/$nama
echo '                       2419200         ; Expire' >> /etc/bind/$nama
echo '                        604800 )       ; Negative Cache TTL' >> /etc/bind/$nama
echo ';' >> /etc/bind/$nama
echo '@       IN      NS      '$domain'.' >> /etc/bind/$nama
echo ''$ip'      IN      PTR     '$domain'.' >> /etc/bind/$nama

./sysadmin/bind/con.sh
