#include <iostream>
using namespace std;

int main() {


  system("clear");

  int ssh;
  int conssh;



    system("chmod 777 sysadmin/logo");
    system("./sysadmin/logo");
      cout<<"           1. Install SSH " <<'\n';
      cout<<"           2. Konfigurasi SSH"<<'\n';
      cout<<"           3. Service Layanan SSH"<<'\n';
      cout<<"           4. Status Layanan SSH"<<'\n';
      cout<<"           5. Menu Utama"<<'\n';
      cout<<"           0. keluar " <<'\n'<<'\n';
      cout<<"   Masukan Pilihan Anda = ";
      cin>>ssh;


      if (ssh==1) {
          system("apt install ssh");
          system("./sysadmin/ssh/ssh.sh");
      }

     else if (ssh==2) {
       system("clear");
       system("chmod 777 sysadmin/logo");
       system("./sysadmin/logo");

          cout<<"           INPUTKAN PILIHAN ANDA "<<'\n'<<'\n';
          cout<<"           1. Port 22(default)"<<'\n';
          cout<<"           2. Coustome Port"<<'\n';
          cout<<"           3. Permit Root Login"<<'\n';
          cout<<"           4. Menu Utama"<<'\n'<<'\n';
          cout<<"           INPUTKAN PILIHAN ANDA = ";

          cin>>conssh;
        }

                  if (conssh==1){
                    system("echo 'Port 22' >> /etc/ssh/sshd_config");
                    system("./sysadmin/ssh/ssh.sh");

                  }

                  else if(conssh==2) {
                  system("chmod 777 sysadmin/ssh/port.sh");
                  system("./sysadmin/ssh/port.sh");

                 }

                 else if(conssh==3) {
                  system("echo 'PermitRootLogin yes' >> /etc/ssh/sshd_config");
                  system("./sysadmin/ssh/ssh.sh");

                 }

                else if(conssh==4){
                  system("./tools.sh");
                }

            else if (ssh==3){
              system("/etc/init.d/ssh restart");
              system("./sysadmin/ssh/ssh.sh");
            }

            else if (ssh==4){
              system("/etc/init.d/ssh status");

            }

            else if (ssh==5){
              system("./tools.sh");
            }

            else if(ssh==0){

            }

            else{
              cout<<"PILIHAN ANDA TIDAK DIKETAHUI ";
            }


      }
