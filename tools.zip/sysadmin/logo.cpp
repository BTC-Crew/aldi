#include <iostream>

using namespace std;

int main(){
  cout<<""<<'\n';
  cout<<"     ooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo"<<'\n';
  cout<<"     #     ██████╗ ████████╗ ██████╗         ██████╗          ██████╗██████╗ ███████╗██╗    ██╗    #"<<'\n';
  cout<<"     #     ██╔══██╗╚══██╔══╝██╔════╝        ██╔═══██╗        ██╔════╝██╔══██╗██╔════╝██║    ██║    #"<<'\n';
  cout<<"     #     ██████╔╝   ██║   ██║             ██║██╗██║        ██║     ██████╔╝█████╗  ██║ █╗ ██║    #"<<'\n';
  cout<<"     #     ██╔══██╗   ██║   ██║             ██║██║██║        ██║     ██╔══██╗██╔══╝  ██║███╗██║    #"<<'\n';
  cout<<"     #     ██████╔╝   ██║   ╚██████╗        ╚█║████╔╝        ╚██████╗██║  ██║███████╗╚███╔███╔╝    #"<<'\n';
  cout<<"     #     ╚═════╝    ╚═╝    ╚═════╝         ╚╝╚═══╝          ╚═════╝╚═╝  ╚═╝╚══════╝ ╚══╝╚══╝     #"<<'\n';
  cout<<"     ooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo"<<'\n'<<'\n';
  cout <<"                 ##########################################################################"<<'\n';
  cout <<"                 #                  SELAMAT DATANG DI TOOLS SYSADMIN                      #"<<'\n';
  cout <<"                 #                            VERSION 1.0.0                               #"<<'\n';
  cout <<"                 #                           By : Aldi Hatomi                             #"<<'\n';
  cout <<"                 ##########################################################################"<<'\n'<<'\n'<<'\n';

}
