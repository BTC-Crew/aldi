#include <iostream>
using namespace std;

int main(){
  int pilihan;

  system("clear");
  system("./sysadmin/logo");

  cout<<"       SILAHKAN PILIH OPSI YANG ANDA INGINKAN"<<'\n'<<'\n';
  cout<<"       1.  Install Apache2 dan package pendukung "<<'\n';
  cout<<"       2.  konfig Apache2 "<<'\n';
  cout<<"       3.  Service restart Apache2 "<<'\n';
  cout<<"       4.  Service status Apache2"<<'\n';
  cout<<"       5.  Service Stop Apache2 "<<'\n';
  cout<<"       88. Menu Utama"<<'\n';
  cout<<"       00. Keluar "<<'\n'<<'\n'<<'\n';
  cout<<"       SILAHKAN MASUKAN PILIHAN ANDA => ";
  cin>>pilihan;



  if (pilihan==1) {
    system("chmod 777 sysadmin/web/conf/install.sh");
    system("./sysadmin/web/conf/install.sh");
    system("");
    system("./sysadmin/web/web | lolcat");
  }

  else if(pilihan==2){
    system("chmod 777 sysadmin/web/conf/konfigapache2.sh");
    system("./sysadmin/web/conf/konfigapache2.sh");
    system("./sysadmin/web/web | lolcat");

  }

  else if(pilihan==88) {
    system("./tools.sh");

  }

  else if(pilihan==00) {

  } else {
    cout<<"PILIHAN ANDA TIDAK DI TEMUKAN";
  }
}
