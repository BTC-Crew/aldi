#!/bin/bash

read -p "     MASUKAN REPO ANDA = " repo;
echo ""$repo >> /etc/apt/sources.list

